// Get the filter buttons and gallery items
const filterBtns = document.querySelectorAll('.filter-btn');
const galleryItems = document.querySelectorAll('.gallery-item');

// Add event listener to each filter button
filterBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    // Get the filter category
    const filterCategory = btn.getAttribute('data-filter');

    // Loop through each gallery item
    galleryItems.forEach((item) => {
      // Get the category of the gallery item
      const itemCategory = item.getAttribute('data-category');

      // If the filter category matches the item category, show the item
      if (filterCategory === itemCategory || filterCategory === 'all') {
        item.classList.remove('hide');
      } else {
        item.classList.add('hide');
      }
    });
  });
});